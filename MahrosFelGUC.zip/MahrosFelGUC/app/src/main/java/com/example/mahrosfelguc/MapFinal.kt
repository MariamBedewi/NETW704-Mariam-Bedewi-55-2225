package com.example.mahrosfelguc

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapFinal : AppCompatActivity(), OnMapReadyCallback {

    private var mGoogleMap: GoogleMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_final)

        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mGoogleMap=googleMap


        //Add Marker
        mGoogleMap?.addMarker(MarkerOptions().position(LatLng(29.98546,31.43908)).title("Marker 1"))
        mGoogleMap?.addMarker(MarkerOptions().position(LatLng(29.98651,31.43904)).title("Marker 2"))

        //Add draggable Marker
        //mGoogleMap?.addMarker(MarkerOptions().position(LatLng(13.234,12.543)).title("Draggable Marker").draggable(true))

        //Add custom Marker
        //mGoogleMap?.addMarker(MarkerOptions().position(LatLng(12.987,14.345)).title("Custom Marker").icon(BitmapDescriptorFactory.fromResource(R.drawable.flag_marker)))


    }


}
