package com.example.mahrosfelguc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var btnMap: Button
    private lateinit var btnProfile: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnMap=findViewById(R.id.btnMap)
        btnProfile=findViewById(R.id.btnProfile)




        btnMap.setOnClickListener {
            val intent= Intent(this,MapFinal::class.java)
            startActivity(intent)
        }

        btnProfile.setOnClickListener {
            val intent= Intent(this,ProfilePage::class.java)
            startActivity(intent)
        }



    }
}