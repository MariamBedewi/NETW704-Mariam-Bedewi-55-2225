package com.example.mahrosfelguc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class SignUp : AppCompatActivity() {

    private lateinit var edtName: EditText
    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnSignUp: Button

    private lateinit var mAuth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_sign_up)

        mAuth= FirebaseAuth.getInstance()

        edtName=findViewById(R.id.edt_name)
        edtEmail=findViewById(R.id.editTextUsername)
        edtPassword=findViewById(R.id.editTextPassword)
        btnSignUp=findViewById(R.id.btnSignUp)

        btnSignUp.setOnClickListener {
            val email= edtEmail.text.toString()
            val password= edtPassword.text.toString()

            signUp(email, password)

        }
    }

    private fun signUp(email: String, password:String){
        //logic for creating a new friend
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this){ task ->
            if(task.isSuccessful){
                // jump to home
                val intent= Intent(this@SignUp, MainActivity::class.java)
                startActivity(intent)
            }
            else{
                //If sign in fails, display a message to the user
                Toast.makeText(this@SignUp,"Oppps Some Error Occurred",Toast.LENGTH_SHORT).show()
            }

        }

    }
}